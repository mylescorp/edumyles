export const radius = {
  "none": 0,
  "xs": 4,
  "sm": 6,
  "md": 8,
  "lg": 12,
  "xl": 16,
  "2xl": 20,
  "full": 9999
} as const;
